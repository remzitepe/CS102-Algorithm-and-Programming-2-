import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.BorderLayout;

import java.util.Iterator;

import javax.swing.*;

import shapes.*;
/*
 * Panel Class
 * @author Tepe_Remzi
 * @version 08.03.2020
 * */


public class BallonsGamePanel extends JPanel{
   
   // constants
   final int NUM_BALLOONS = 25;
   final int RADIUS = 25;
   final int WIDTH = 700;
   final int HEIGHT = 600;
   final int TIME = 250;
   final int FIXED_PERIOD = 15;
   
   // properties
   ShapeContainer balloons;
   Balloon balloon;
   MyMousePressed mouseListener;
   JPanel panel;
   JLabel scoreTable, elapsedTime;
   int point, timeElapsed;
   int x, y,passValue;
   Timer timer;
   
   // constructor
   public BallonsGamePanel() {
      
      scoreTable = new JLabel("Points: " + point );
      elapsedTime = new JLabel( "Elapsed Time: " + timeElapsed );
      
      setLayout( new BorderLayout() );
      
      scoreTable.setHorizontalAlignment( SwingConstants.CENTER);
      add( scoreTable, BorderLayout.PAGE_START);
      
      elapsedTime.setHorizontalAlignment( SwingConstants.RIGHT);
      
      add( elapsedTime, BorderLayout.PAGE_END);
      
      setBackground( Color.cyan);
      setPreferredSize( new Dimension( WIDTH, HEIGHT) );
      setVisible( true );
      balloons = new ShapeContainer();
      startOver();
   }
   
   @Override
   public void paintComponent( Graphics g) {
      
      super.paintComponent( g);
      
      Iterator<Shape> balloonIterator = balloons.iterator();
      while( balloonIterator.hasNext() ) {
         (( Drawable) balloonIterator.next()).draw( g); 
      }      
   }
   
   // inner class
   class MyMousePressed extends MouseAdapter{
      
      @Override
      public void mousePressed(MouseEvent e) {
         int count;
         count = 0;
         Iterator iterator = balloons.iterator();
         while( iterator.hasNext() ){
            if ( ((Balloon)iterator.next()).contains( e.getX(), e.getY()) != null ){
               
               count++; 
               if( count > 1 )
                  point++;
            }
         }
         balloons.selectAtAll( e.getX(), e.getY()); 
         balloons.removeSelectedShape();
      }
   }
   
   // inner Class
   class MyActionListener implements ActionListener{
      
      @Override
      public void actionPerformed(ActionEvent e) {
         Iterator<Shape> balloonItr = balloons.iterator();
         while( balloonItr.hasNext() ) {
            (( Balloon) balloonItr.next()).grow(); 
         }
         while( balloons.size() < 15 ){
            int xRandom, yRandom;
            xRandom = ( int)( Math.random() * WIDTH  + 1);
            yRandom = ( int)( Math.random() * HEIGHT  + 1);
            balloon = new Balloon( RADIUS, xRandom, yRandom);
            balloons.add( balloon);
         }
         balloons.removeSelectedShape();
         repaint();
         passValue++;
         if( passValue % ( 1000 / TIME ) == 0 ){
            
            timeElapsed = timeElapsed + 1;
         }
         if( timeElapsed >= FIXED_PERIOD ){
            int option;
            timer.stop();
            removeMouseListener( mouseListener );
            option = JOptionPane.showConfirmDialog( BallonsGamePanel.this, "Play Again ?" , "Game Over ", 0);
            if( option == JOptionPane.YES_OPTION){
               
               Iterator<Shape> balloonItrx = balloons.iterator();
               while(  balloonItrx.hasNext() ) {
                  (( Balloon) balloonItrx.next()).setSelected( true );
               }    
               balloons.removeSelectedShape();
               startOver();
               scoreTable.setText("Points " + point );
               elapsedTime.setText("Elapsed Time: " + timeElapsed);
               
            }
            else if( option == JOptionPane.NO_OPTION){
               System.exit(0);
            }
         }
         scoreTable.setText("Points: " + point);
         elapsedTime.setText("Elapsed Time: " + timeElapsed);
      }
   }
   
   // start over method
   public void startOver(){
      timeElapsed = 0;
      point = 0;
      passValue = 0;
      timer = new Timer( TIME, new MyActionListener() );
      timer.start();
      mouseListener = new MyMousePressed();
      addMouseListener( mouseListener );
      for( int i = 0; i < NUM_BALLOONS; i++) {
         x = ( int)( Math.random() * ( WIDTH ) + 1);
         y = ( int)( Math.random() * ( HEIGHT )+ 1);
         balloon = new Balloon( RADIUS, x, y);
         balloons.add( balloon);
      }
   }
}
