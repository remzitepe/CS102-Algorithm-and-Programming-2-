package shapes;
/*
 * Circle
 * @author Tepe_Remzi
 * @version 08.03.2020
 * */

public class Circle extends Shape implements Selectable {
    // constants
    private final String name = "Circle";
    
    // properties 
    int radius;
    int x;
    int y;
    boolean selected;
    
    // constructor
    /*
     * it takes radius and locations
     *@param radius, x, y 
     * */
    public Circle( int radius, int x, int y)
    {
     this.radius = radius;  
     setLocation( x, y );
    }
    
    /*
     * it makes selected 
     *@return boolean type of selected
     * */
    public boolean getSelected()
    {
       return selected;
    }
    
    /*
     * takes a selected with boolean type and set it selected
     *@return boolean type of selected 
     * */
    public void setSelected( boolean selected )
    {
       this.selected = selected;
    }
    
    /*
     * Control if object shape contains given locations
     *@return Shape type of shapes
     * */
  public Shape contains( int a, int b)
  {
     Circle circle = new Circle( radius, getX(), getY() );
    if ( Math.pow(Math.abs( a - getX() ), 2)  + Math.pow(Math.abs(b - getY() ), 2) <= radius * radius)
    {
      return circle;
    }
    else
    {
      return null;
    }
  }
    /*
     * compile the area of the shape
     *@return double type of area  
     * */
    double getArea()
    {
       double area;
       area =  radius * radius * Math.PI;
       return area;
    }
    /*
     * show the features of the shape
     *@return String type of info  
     * */
    public String toString()
    {  
       String features;
       String str;
       str = " not selected ";
       if( selected )
       {
          str = " selected ";
       }
       features = name + " is located in " + getX() + ", " + getY() + " radius: " + radius + " and area: "
          + getArea() + " and is " + str;
       
       return features;
    }
}
