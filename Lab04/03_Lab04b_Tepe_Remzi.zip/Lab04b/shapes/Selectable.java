package shapes;
/*
 * Selectable
 * @author Tepe_Remzi
 * @version 08.03.2020
 * */

public interface Selectable {
  boolean getSelected();
    
    void setSelected( boolean b );
    
    Shape contains( int x, int y );
}
