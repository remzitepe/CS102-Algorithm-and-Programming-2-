package shapes;
/*
 * Locatable
 * @author Tepe_Remzi
 * @version 08.03.2020
 * */

public interface Locatable {
  int getX();
  int getY();
  void setLocation( int x, int y);
}
