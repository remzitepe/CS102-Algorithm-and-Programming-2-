package shapes;

import java.util.Iterator;
import java.util.ArrayList;
/*
 * ShapeContainer
 * @author Tepe_Remzi
 * @version 08.03.2020
 * */


public class ShapeContainer implements Iterable {
   
   // properties   
   private ArrayList <Shape> shapes;
   private int x;
   private int y;
   
   // constructor
   
   /*
    * creates arraylist of shape
    * */
   public ShapeContainer(){
      shapes = new ArrayList <Shape>();  
   }
   
   /*
    * adds Shape object
    * @param s Shape object
    * */
   public void add( Shape s ){
      
      shapes.add( s ); 
   }
   
   /*
    * calculates the area
    * @return double all area of the shapes 
    * */
   public double getArea(){
      
      double allArea;
      
      allArea = 0;
      
      for ( int i = 0; i < shapes.size(); i++)
      {
         allArea = allArea + shapes.get( i ).getArea();
      }
      return allArea;
   }
   
   /*
    * show the all shapes infos
    * @return String type of features 
    * */
   public String toString(){
      
      String str;
      
      str = "";
      
      for( int i = 0; i < shapes.size(); i++)
      {  
         str = str + "Shape " + i + " is: " + shapes.get( i ).toString() + "\n";   
      }
      return str;
   }
   
   
   /*
    * controls if locations are in the shapes
    * */
   public void findFirstShape( int x, int y )
   {
      int count;
      count = 0;
      for( int i = 0; i < shapes.size(); i++)
      {
         if(  ( ( Selectable )shapes.get( i ) ).contains( x, y )  != null && count < 1)
         {
            ( ( Selectable )shapes.get( i ) ).setSelected( true );
            System.out.println( shapes.get( i ).toString() + " is the first shape with given locations. " );
            count++;
         }
         else
            System.out.println( shapes.get( i ).toString() + " is not containing ");  
      }
      if( count < 1 )
      {
         System.out.println( " So, there is no such shape containing those locations " );
      }
   }
   
   
   /*
    *removes selectedShapes
    * */
    public void removeSelectedShape()
   {
      for( int i = 0; i < shapes.size(); i++ )
      {
         if((( Selectable )shapes.get( i ) ).getSelected() )
         {
            shapes.remove( shapes.get( i ) );
         }
      }
   }
   
   
   public int size(){
      
      return shapes.size();
   }
   
   public int selectAtAll( int x, int y )
   {
      int count;
      count = 0;
      for( int i = 0; i < shapes.size(); i++)
      {
            if( ( ( Selectable )shapes.get( i ) ).contains(x, y) != null) {
               count++;
               ( ( Selectable )shapes.get( i ) ).setSelected( true);
            }
      }
      return count;
   }
   

   @Override
   public Iterator<Shape> iterator() {
      myIterator<Shape> Iteratorx;
      Iteratorx = new myIterator<Shape>();
      return Iteratorx;
   }
 // inner class MyIterator
   class myIterator<Shape> implements Iterator<Shape> {
      
      private int index;
      
      public myIterator() {
         index = 0;
      }
      
      //@Override
      public boolean hasNext() {
         if( index < shapes.size() ) {
            index++;
            return true;
         }
         return false;
      }
      
      public Shape next() {
         Shape shape;
         shape = ( Shape)( shapes.get( index - 1));
  
         return shape;
      }

      
      //@Override
      public void remove() {
         shapes.remove( index - 1);
      }
   }
   public Shape contains(int x, int y) {
      for (int i = 0 ; i < shapes.size() ; i++ ) {
         if(((Selectable)shapes.get(i)).contains(x, y) == shapes.get(i)) {
            ((Selectable)shapes.get(i)).setSelected(true);
            return shapes.get(i);
         }
      }
      return null;
   }
   
   
}
