package shapes;

import java.awt.*;
/*
 * Drawable
 * @author Tepe_Remzi
 * @version 08.03.2020
 * */

public interface Drawable{
    
  void draw( Graphics g );  
}  