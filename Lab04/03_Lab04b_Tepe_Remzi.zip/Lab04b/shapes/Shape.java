package shapes;

/*
 * Shape
 * @author Tepe_Remzi
 * @version 08.03.2020
 * */

public abstract class Shape implements Locatable{

// properties
int x;
int y;

abstract double getArea();

public int getX()
{
   return x;
}

public int getY()
{
   return y;
}

public void setLocation( int x, int y)
{
   this.x = x;
   this.y = y;
}
}