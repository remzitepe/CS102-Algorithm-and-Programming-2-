import java.awt.*;

import shapes.*;
/*
 * Balloon
 * @author Tepe_Remzi
 * @version 08.03.2020
 * */
public class Balloon extends Circle implements Drawable {

 // constants
 final int MAXRADIUS = 100;
 
 // properties
 int radius, x, y;
 
 // constructor
 public Balloon(int radius, int x, int y) {
  super( radius, x, y);
  this.radius = radius;
 }

 // methods
 
 @Override
 public void draw(Graphics g ) {
  g.setColor( Color.black);
  g.drawOval( getX() - this.radius, getY() 
    - this.radius, 2 * this.radius, 2 * this.radius);
 }
 
 public void grow() {
  
  radius++;
  if( radius >= MAXRADIUS) {
   setSelected( true);
   radius = 0;
  }
 }
}
