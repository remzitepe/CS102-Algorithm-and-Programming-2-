import java.util.Scanner;

import javax.swing.*;

import shapes.*;
/*
 * Application
 * @author Tepe_Remzi
 * @version 08.03.2020
 * */

public class Application {

 public static void main( String[] args) {
  
  Scanner scan = new Scanner( System.in);
  
  // variables
  JFrame f;
  
  // program code
  f = new BallonsGameFrame();
  
 }
}
