import javax.swing.*;

import shapes.*;

import java.awt.*;
/*
 * Frame Class
 * @author Tepe_Remzi
 * @version 08.03.2020
 * */
public class BallonsGameFrame extends JFrame {

 // constructor
   public BallonsGameFrame() {
      
      JPanel p;
      setLayout( new FlowLayout() );
      setTitle( "Balloons");
      p = new BallonsGamePanel();
      add( p);
      pack();
      setVisible( true);
   }
}
